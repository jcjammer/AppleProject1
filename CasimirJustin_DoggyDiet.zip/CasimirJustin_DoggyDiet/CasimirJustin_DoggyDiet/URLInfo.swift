//
//  URLInfo.swift
//  CasimirJustin_DoggyDiet
//
//  Created by Justin Casimir on 5/30/19.
//  Copyright © 2019 Justin Casimir. All rights reserved.
//

import Foundation
import UIKit

class URLInfo {
    let id: Int
    let url: String
       
    init(id: Int, url: String){
        self.id = id
        self.url = url
       
    }
}
