//
//  CoreData.swift
//  CasimirJustin_DoggyDiet
//
//  Created by Justin Casimir on 5/30/19.
//  Copyright © 2019 Justin Casimir. All rights reserved.
//

import Foundation
